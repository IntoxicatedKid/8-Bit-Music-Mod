## 8 Bit Music Mod
Very wip. Only a few music is added or replaced for now.

Music and credit:  
Reimu(replace): https://www.youtube.com/watch?v=UDFNDeuvFQ8&t=3s  
Act3(replace): https://www.youtube.com/watch?v=_sFZWSqdOjQ  
Rabbits(new): https://www.youtube.com/watch?v=C4faL2XzywQ  
Doremy(new): https://www.youtube.com/watch?v=Lq6vxwL5eCU  
Junko(replace): https://www.youtube.com/watch?v=UEpiASdLRYc

Lost Branch of Legend By Alioth Studio  
BepInEx by BepInEx  
LBoL-Entity-Sideloader by Neoshrimp#7746  